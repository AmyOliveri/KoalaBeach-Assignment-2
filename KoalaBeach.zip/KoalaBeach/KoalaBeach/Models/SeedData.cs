﻿using System.Linq;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;

namespace KoalaBeach.Models
{
    public static class SeedData
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            StoreDbContext context = app.ApplicationServices
                .CreateScope().ServiceProvider.GetRequiredService<StoreDbContext>();
            if (context.Database.GetPendingMigrations().Any())
            {
                context.Database.Migrate();
            }
            if (!context.Products.Any())
            {
                context.Products.AddRange(
                    new Product
                    {
                        Name = "T Shirt",
                        Description = "Groovy T Shirt",
                        Category = "Shirt",
                        SubCategory = "Men",
                        Price = 15
                    },
                    new Product
                    {
                        Name = "Single Top",
                        Description = "Singlet style top",
                        Category = "Shirt",
                        SubCategory = "Men",
                        Price = 20
                    }
                );
                context.SaveChanges();
            }
        }
    }
}

